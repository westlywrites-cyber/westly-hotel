import type { PagesFunction } from "@cloudflare/workers-types";
import { requireActiveUser, jsonResponse, HttpError, type Env } from "./_shared/admin";
import { getDoc, queryCollection, updateDoc } from "./_shared/firestoreRest";
import { sendEachForMulticast } from "./_shared/fcm";

interface SendPushBody {
  forRoles?: string[];
  forUserIds?: string[];
  excludeUserId?: string | null;
  title: string;
  body: string;
  link?: string;
  notificationId?: string;
}

// Firestore 'in' queries top out at 10 values — the role list is small and
// fixed (7 roles), so this is always safe without chunking.
const MAX_IN_CLAUSE = 10;

export const onRequestPost: PagesFunction<Env> = async (context) => {
  try {
    await requireActiveUser(context.env, context.request.headers.get("authorization"));
    const payload = await context.request.json<SendPushBody>();

    if (!payload.title || !payload.body) {
      throw new HttpError(400, "title and body are required.");
    }
    const roles = (payload.forRoles ?? []).slice(0, MAX_IN_CLAUSE);
    const userIds = payload.forUserIds ?? [];

    if (roles.length === 0 && userIds.length === 0) {
      return jsonResponse(200, { sent: 0, reason: "no target roles or users" });
    }

    // Gather the target users: everyone matching a target role, plus any
    // explicitly named user ids, minus the actor (if they shouldn't be pinged
    // about their own action) and minus suspended/deleted accounts.
    const userDocs = new Map<string, Record<string, any>>();

    if (roles.length > 0) {
      const snap = await queryCollection(context.env, "users", [{ field: "role", op: "IN", value: roles }]);
      snap.forEach((d) => userDocs.set(d.id, d.data()!));
    }
    if (userIds.length > 0) {
      const results = await Promise.all(userIds.map((id) => getDoc(context.env, "users", id)));
      results.forEach((d) => {
        if (d.exists) userDocs.set(d.id, d.data()!);
      });
    }
    if (payload.excludeUserId) userDocs.delete(payload.excludeUserId);

    const tokens: string[] = [];
    userDocs.forEach((data) => {
      if (data.status !== "active" || data.isDeleted) return;
      const userTokens: string[] = Array.isArray(data.fcmTokens) ? data.fcmTokens : [];
      tokens.push(...userTokens);
    });

    if (tokens.length === 0) {
      return jsonResponse(200, { sent: 0, reason: "no registered devices for target users" });
    }

    const result = await sendEachForMulticast(context.env, tokens, {
      notification: { title: payload.title, body: payload.body },
      data: {
        link: payload.link ?? "/admin/dashboard",
        notificationId: payload.notificationId ?? "",
      },
      webpush: {
        fcmOptions: { link: payload.link ?? "/admin/dashboard" },
        notification: { icon: "/admin-icons/admin-icon-192.png" },
      },
    });

    // Prune tokens that are no longer valid (uninstalled/expired) so the
    // fcmTokens arrays don't grow unbounded with dead entries over time.
    const invalidTokens: string[] = [];
    result.responses.forEach((r, i) => {
      if (!r.success && r.shouldPruneToken) invalidTokens.push(tokens[i]);
    });
    if (invalidTokens.length > 0) {
      const invalidSet = new Set(invalidTokens);
      const cleanupWrites: Promise<unknown>[] = [];
      userDocs.forEach((data, uid) => {
        const userTokens: string[] = Array.isArray(data.fcmTokens) ? data.fcmTokens : [];
        const kept = userTokens.filter((t) => !invalidSet.has(t));
        if (kept.length !== userTokens.length) {
          cleanupWrites.push(updateDoc(context.env, "users", uid, { fcmTokens: kept }));
        }
      });
      await Promise.all(cleanupWrites);
    }

    return jsonResponse(200, { sent: result.successCount, failed: result.failureCount });
  } catch (err: any) {
    if (err instanceof HttpError) return jsonResponse(err.statusCode, { error: err.message });
    return jsonResponse(500, { error: err?.message || "Failed to send push notification." });
  }
};
