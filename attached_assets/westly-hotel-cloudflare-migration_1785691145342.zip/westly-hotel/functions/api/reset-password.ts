import type { PagesFunction } from "@cloudflare/workers-types";
import { requireSuperAdmin, jsonResponse, HttpError, type Env } from "./_shared/admin";
import { logServerAction } from "./_shared/serverAudit";
import { updateUser } from "./_shared/firebaseAuthRest";

export const onRequestPost: PagesFunction<Env> = async (context) => {
  try {
    const caller = await requireSuperAdmin(context.env, context.request.headers.get("authorization"));
    const { uid, newPassword } = await context.request.json<{ uid?: string; newPassword?: string }>();

    if (!uid || !newPassword) {
      throw new HttpError(400, "uid and newPassword are required.");
    }
    if (newPassword.length < 8) {
      throw new HttpError(400, "Password must be at least 8 characters.");
    }

    await updateUser(context.env, uid, { password: newPassword });

    await logServerAction(context.env, caller.uid, caller.name, "password_reset", "users", uid);

    return jsonResponse(200, { success: true });
  } catch (err: any) {
    if (err instanceof HttpError) return jsonResponse(err.statusCode, { error: err.message });
    return jsonResponse(400, { error: err?.message || "Failed to reset password." });
  }
};
