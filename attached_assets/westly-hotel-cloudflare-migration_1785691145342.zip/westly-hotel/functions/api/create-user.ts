import type { PagesFunction } from "@cloudflare/workers-types";
import { requireSuperAdmin, jsonResponse, HttpError, type Env } from "./_shared/admin";
import { logServerAction } from "./_shared/serverAudit";
import { setDoc } from "./_shared/firestoreRest";
import { createUser } from "./_shared/firebaseAuthRest";

async function hashPin(pin: string): Promise<string> {
  const data = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

interface CreateUserBody {
  name?: string;
  email?: string;
  password?: string;
  phone?: string;
  role?: string;
  pin?: string;
}

export const onRequestPost: PagesFunction<Env> = async (context) => {
  try {
    const caller = await requireSuperAdmin(context.env, context.request.headers.get("authorization"));
    const { name, email, password, phone, role, pin } = await context.request.json<CreateUserBody>();

    if (!name || !email || !password || !role) {
      throw new HttpError(400, "name, email, password, and role are required.");
    }
    if (password.length < 8) {
      throw new HttpError(400, "Password must be at least 8 characters.");
    }
    if (pin && pin.length < 4) {
      throw new HttpError(400, "PIN must be at least 4 digits.");
    }

    // 1. Create the real Firebase Auth account (Admin REST call — does NOT
    //    sign in the calling browser, same as the Admin SDK's createUser).
    const userRecord = await createUser(context.env, { email, password, displayName: name });

    // 2. Write the Firestore profile doc, keyed by the Auth uid.
    const pinHash = pin ? await hashPin(pin) : null;
    await setDoc(context.env, "users", userRecord.uid, {
      name,
      email,
      phone: phone || null,
      role,
      status: "active",
      pinHash,
      isDeleted: false,
      createdAt: new Date(),
      createdBy: caller.uid,
    });

    await logServerAction(
      context.env,
      caller.uid,
      caller.name,
      "user_created",
      "users",
      userRecord.uid,
      null,
      { name, email, role }
    );

    return jsonResponse(200, { uid: userRecord.uid });
  } catch (err: any) {
    if (err instanceof HttpError) return jsonResponse(err.statusCode, { error: err.message });
    // Auth REST errors (e.g. "The email address is already in use...") already
    // have a readable .message, same as the Admin SDK's auth/email-already-exists.
    return jsonResponse(400, { error: err?.message || "Failed to create user." });
  }
};
