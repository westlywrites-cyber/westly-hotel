// ══════════════════════════════════════════════════════════════════════════
// Shared caller-authorization helpers for all Cloudflare Pages Functions in
// this folder. Direct port of netlify/functions/_shared/admin.ts — same
// logic, same Firestore collection/field names — just backed by the REST
// clients in ./firestoreRest and ./firebaseAuthRest instead of firebase-admin,
// and returning a native Response instead of Netlify's {statusCode,...} shape.
// ══════════════════════════════════════════════════════════════════════════
import { getDoc } from "./firestoreRest";
import { verifyIdToken } from "./firebaseAuthRest";
import type { Env } from "./googleAuth";

export type { Env };

export class HttpError extends Error {
  constructor(public statusCode: number, message: string) {
    super(message);
  }
}

export function jsonResponse(statusCode: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status: statusCode,
    headers: { "Content-Type": "application/json" },
  });
}

/**
 * Verifies the caller's Firebase ID token (sent as "Authorization: Bearer <token>")
 * and confirms they are an active super_admin according to Firestore. Throws
 * HttpError on any failure — callers should catch and translate to a response.
 */
export async function requireSuperAdmin(env: Env, authHeader: string | null | undefined) {
  if (!authHeader?.startsWith("Bearer ")) {
    throw new HttpError(401, "Missing Authorization header.");
  }
  const idToken = authHeader.slice("Bearer ".length);

  let decoded;
  try {
    decoded = await verifyIdToken(env, idToken);
  } catch {
    throw new HttpError(401, "Invalid or expired session. Please sign in again.");
  }

  const callerSnap = await getDoc(env, "users", decoded.uid);
  const caller = callerSnap.data();

  if (
    !callerSnap.exists ||
    caller?.role !== "super_admin" ||
    caller?.status !== "active" ||
    caller?.isDeleted
  ) {
    throw new HttpError(403, "Only an active Super Admin can perform this action.");
  }

  return { uid: decoded.uid, name: caller.name as string };
}

/**
 * Verifies the caller's Firebase ID token and confirms they are ANY active,
 * non-deleted admin/staff user (not necessarily super_admin). Used by
 * functions like send-push that are legitimately called by every role —
 * every staff action that triggers a notification needs to be able to ask
 * for that notification to be pushed.
 */
export async function requireActiveUser(env: Env, authHeader: string | null | undefined) {
  if (!authHeader?.startsWith("Bearer ")) {
    throw new HttpError(401, "Missing Authorization header.");
  }
  const idToken = authHeader.slice("Bearer ".length);

  let decoded;
  try {
    decoded = await verifyIdToken(env, idToken);
  } catch {
    throw new HttpError(401, "Invalid or expired session. Please sign in again.");
  }

  const callerSnap = await getDoc(env, "users", decoded.uid);
  const caller = callerSnap.data();

  if (!callerSnap.exists || caller?.status !== "active" || caller?.isDeleted) {
    throw new HttpError(403, "Only an active staff account can perform this action.");
  }

  return { uid: decoded.uid, name: caller.name as string, role: caller.role as string };
}
