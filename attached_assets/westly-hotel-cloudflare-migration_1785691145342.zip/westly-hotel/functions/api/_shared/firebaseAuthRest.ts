// ══════════════════════════════════════════════════════════════════════════
// Replaces the pieces of firebase-admin's Auth module this project actually
// uses: verifyIdToken, createCustomToken, createUser, updateUser.
// ══════════════════════════════════════════════════════════════════════════
import { SignJWT, importPKCS8, jwtVerify, createRemoteJWKSet } from "jose";
import { getAccessToken, getServiceAccount, type Env } from "./googleAuth";

const IDENTITY_TOOLKIT_BASE = "https://identitytoolkit.googleapis.com/v1";

// Google publishes the current signing keys for Firebase ID tokens as a
// JWKS at this well-known URL — the same source firebase-admin fetches
// under the hood to verify tokens without needing its own secret.
const jwks = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/[email protected]")
);

export interface DecodedIdToken {
  uid: string;
  [claim: string]: unknown;
}

/** Equivalent to adminAuth.verifyIdToken(idToken). */
export async function verifyIdToken(env: Env, idToken: string): Promise<DecodedIdToken> {
  const sa = getServiceAccount(env);
  const { payload } = await jwtVerify(idToken, jwks, {
    issuer: `https://securetoken.google.com/${sa.project_id}`,
    audience: sa.project_id,
  });

  if (!payload.sub) {
    throw new Error("ID token missing subject claim.");
  }
  return { ...payload, uid: payload.sub };
}

/** Equivalent to adminAuth.createCustomToken(uid, claims). */
export async function createCustomToken(
  env: Env,
  uid: string,
  claims?: Record<string, unknown>
): Promise<string> {
  const sa = getServiceAccount(env);
  const privateKey = await importPKCS8(sa.private_key, "RS256");
  const now = Math.floor(Date.now() / 1000);

  return new SignJWT({
    uid,
    claims: claims ?? {},
  })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setSubject(sa.client_email)
    .setAudience(
      "https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit"
    )
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(privateKey);
}

/** Equivalent to adminAuth.createUser({ email, password, displayName }). */
export async function createUser(
  env: Env,
  input: { email: string; password: string; displayName?: string }
): Promise<{ uid: string }> {
  const sa = getServiceAccount(env);
  const token = await getAccessToken(env);

  const res = await fetch(`${IDENTITY_TOOLKIT_BASE}/accounts:signUp`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email: input.email,
      password: input.password,
      displayName: input.displayName,
      targetProjectId: sa.project_id,
      returnSecureToken: false,
    }),
  });

  const json: any = await res.json().catch(() => ({}));
  if (!res.ok) {
    // Surface Google's message the same way firebase-admin's error.message did
    // (e.g. "EMAIL_EXISTS") so existing catch blocks that read err.message
    // behave the same as before.
    throw new Error(mapAuthError(json?.error?.message) || "Failed to create user.");
  }
  return { uid: json.localId as string };
}

/** Equivalent to adminAuth.updateUser(uid, { password?, disabled? }). */
export async function updateUser(
  env: Env,
  uid: string,
  updates: { password?: string; disabled?: boolean }
): Promise<void> {
  const sa = getServiceAccount(env);
  const token = await getAccessToken(env);

  const body: Record<string, unknown> = {
    localId: uid,
    targetProjectId: sa.project_id,
  };
  if (updates.password !== undefined) body.password = updates.password;
  if (updates.disabled !== undefined) body.disableUser = updates.disabled;

  const res = await fetch(`${IDENTITY_TOOLKIT_BASE}/accounts:update`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const json: any = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(mapAuthError(json?.error?.message) || "Failed to update user.");
  }
}

// Translate Identity Toolkit's SCREAMING_SNAKE error codes into the same
// human-readable strings firebase-admin's error.message already gave the
// client (call sites do `err?.message || "Failed to ..."`, unchanged).
function mapAuthError(code: string | undefined): string | null {
  switch (code) {
    case "EMAIL_EXISTS":
      return "The email address is already in use by another account.";
    case "INVALID_EMAIL":
      return "The email address is badly formatted.";
    case "WEAK_PASSWORD : Password should be at least 6 characters":
    case "WEAK_PASSWORD":
      return "The password must be at least 6 characters long.";
    case "USER_NOT_FOUND":
      return "There is no user record corresponding to this identifier.";
    default:
      return code ?? null;
  }
}
