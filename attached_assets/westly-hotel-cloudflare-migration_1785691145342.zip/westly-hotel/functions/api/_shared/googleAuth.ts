// ══════════════════════════════════════════════════════════════════════════
// Replaces firebase-admin's credential bootstrap for the Cloudflare Workers
// runtime. firebase-admin itself can't run here — its Firestore client uses
// Node's net/tls/gRPC stack and its Auth client relies on Node's http(s)
// agent internals, neither of which exist in the Workers V8 isolate.
//
// Instead we do exactly what firebase-admin does under the hood, over plain
// REST: sign a short-lived JWT with the service account's private key
// (RS256, via Web Crypto through `jose`) and exchange it with Google's OAuth
// token endpoint for an access token. That access token is then attached as
// a Bearer header to Firestore REST calls and Identity Toolkit REST calls.
// ══════════════════════════════════════════════════════════════════════════
import { SignJWT, importPKCS8 } from "jose";

export interface ServiceAccount {
  project_id: string;
  client_email: string;
  private_key: string;
}

export interface Env {
  FIREBASE_SERVICE_ACCOUNT_KEY: string;
  [key: string]: unknown;
}

const TOKEN_URL = "https://oauth2.googleapis.com/token";
const SCOPES = [
  // Covers both Firestore REST and Identity Toolkit REST admin calls —
  // the same broad scope firebase-admin requests by default.
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/identitytoolkit",
  "https://www.googleapis.com/auth/firebase.messaging",
].join(" ");

let cachedServiceAccount: ServiceAccount | null = null;

export function getServiceAccount(env: Env): ServiceAccount {
  if (cachedServiceAccount) return cachedServiceAccount;

  const raw = env.FIREBASE_SERVICE_ACCOUNT_KEY;
  if (!raw) {
    throw new Error(
      "FIREBASE_SERVICE_ACCOUNT_KEY env var is not set. Add the base64-encoded " +
        "service account JSON in Cloudflare Pages → Settings → Environment variables → Secrets."
    );
  }

  // atob is the Workers-native way to decode base64 (no Buffer global here).
  const json = atob(raw);
  const parsed = JSON.parse(json);

  if (!parsed.project_id || !parsed.client_email || !parsed.private_key) {
    throw new Error(
      "FIREBASE_SERVICE_ACCOUNT_KEY did not decode to a valid service account JSON " +
        "(missing project_id, client_email, or private_key)."
    );
  }

  cachedServiceAccount = {
    project_id: parsed.project_id,
    client_email: parsed.client_email,
    private_key: parsed.private_key,
  };
  return cachedServiceAccount;
}

// Module-scope cache. Workers isolates are frequently reused between
// requests (the same pattern firebase-admin relies on for its own token
// caching), so this avoids a fresh sign+exchange round trip on every call
// without needing any external cache.
let cachedAccessToken: { token: string; expiresAt: number } | null = null;

export async function getAccessToken(env: Env): Promise<string> {
  const now = Math.floor(Date.now() / 1000);

  if (cachedAccessToken && cachedAccessToken.expiresAt - 60 > now) {
    return cachedAccessToken.token;
  }

  const sa = getServiceAccount(env);
  const privateKey = await importPKCS8(sa.private_key, "RS256");

  const assertion = await new SignJWT({ scope: SCOPES })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setSubject(sa.client_email)
    .setAudience(TOKEN_URL)
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(privateKey);

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Failed to obtain Google OAuth access token (${res.status}): ${text}`);
  }

  const data = (await res.json()) as { access_token: string; expires_in: number };
  cachedAccessToken = { token: data.access_token, expiresAt: now + data.expires_in };
  return data.access_token;
}
