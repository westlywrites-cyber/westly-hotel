import { getAccessToken, getServiceAccount, type Env } from "./googleAuth";

export interface PushMessage {
  notification: { title: string; body: string };
  data?: Record<string, string>;
  webpush?: {
    fcmOptions?: { link?: string };
    notification?: { icon?: string };
  };
}

export interface SendResult {
  successCount: number;
  failureCount: number;
  /** Per-token result, in the same order as the input tokens array. */
  responses: Array<{ success: boolean; shouldPruneToken: boolean }>;
}

// Token-invalidity error codes from FCM's v1 API error format
// (google.firebase.fcm.v1.FcmError.errorCode) that correspond to what the
// Admin SDK reported as messaging/registration-token-not-registered and
// messaging/invalid-registration-token.
const PRUNE_ERROR_CODES = new Set(["UNREGISTERED", "INVALID_ARGUMENT"]);

/**
 * Sends one push notification to each token individually via FCM's HTTP v1
 * API. Equivalent to admin.messaging().sendEachForMulticast(...) — the
 * Admin SDK's "multicast" is itself just this same per-token fan-out done
 * for you, since FCM v1 has no batch/multicast send endpoint.
 */
export async function sendEachForMulticast(env: Env, tokens: string[], message: PushMessage): Promise<SendResult> {
  const sa = getServiceAccount(env);
  const token = await getAccessToken(env);
  const url = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;

  const responses = await Promise.all(
    tokens.map(async (deviceToken) => {
      const res = await fetch(url, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          message: {
            token: deviceToken,
            notification: message.notification,
            data: message.data,
            webpush: message.webpush,
          },
        }),
      });

      if (res.ok) return { success: true, shouldPruneToken: false };

      const errJson: any = await res.json().catch(() => ({}));
      const fcmError = (errJson?.error?.details || []).find(
        (d: any) => d["@type"] === "type.googleapis.com/google.firebase.fcm.v1.FcmError"
      );
      const errorCode: string | undefined = fcmError?.errorCode;
      return { success: false, shouldPruneToken: !!errorCode && PRUNE_ERROR_CODES.has(errorCode) };
    })
  );

  const successCount = responses.filter((r) => r.success).length;
  return { successCount, failureCount: responses.length - successCount, responses };
}
