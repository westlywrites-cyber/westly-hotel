import type { PagesFunction } from "@cloudflare/workers-types";
import { requireSuperAdmin, jsonResponse, HttpError, type Env } from "./_shared/admin";
import { logServerAction } from "./_shared/serverAudit";
import { getDoc, updateDoc } from "./_shared/firestoreRest";
import { updateUser } from "./_shared/firebaseAuthRest";

export const onRequestPost: PagesFunction<Env> = async (context) => {
  try {
    const caller = await requireSuperAdmin(context.env, context.request.headers.get("authorization"));
    const { uid, status } = await context.request.json<{ uid?: string; status?: string }>();

    if (!uid || (status !== "active" && status !== "suspended")) {
      throw new HttpError(400, "uid and status ('active' | 'suspended') are required.");
    }

    // Disable the real Firebase Auth account when suspending — previously
    // only a Firestore field changed, so a suspended user's password (or an
    // existing session) still worked for anything not gated by Firestore rules.
    await updateUser(context.env, uid, { disabled: status === "suspended" });

    const prevSnap = await getDoc(context.env, "users", uid);
    await updateDoc(context.env, "users", uid, { status, updatedAt: new Date() });

    await logServerAction(
      context.env,
      caller.uid,
      caller.name,
      `user_${status}`,
      "users",
      uid,
      { status: prevSnap.data()?.status },
      { status }
    );

    return jsonResponse(200, { success: true });
  } catch (err: any) {
    if (err instanceof HttpError) return jsonResponse(err.statusCode, { error: err.message });
    return jsonResponse(400, { error: err?.message || "Failed to update user status." });
  }
};
