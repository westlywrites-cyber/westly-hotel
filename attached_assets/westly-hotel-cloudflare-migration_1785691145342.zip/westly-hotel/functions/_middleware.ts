// ══════════════════════════════════════════════════════════════════════════
// Subdomain routing — the one piece of netlify.toml that has NO direct
// Cloudflare Pages equivalent. Netlify's `_redirects`/`netlify.toml` can
// match on Host (e.g. "https://admin.*/*"); Cloudflare's `_redirects` /
// `_headers` files are path-only and never see the Host header. So the
// admin.yourdomain.com and hotel.yourdomain.com subdomain behavior has to
// move into a Worker that runs in front of every request instead — this
// file. It runs before both static asset serving AND the /api/* functions,
// so it explicitly skips API routes to avoid mangling those paths when a
// staff member is on admin.yourdomain.com calling /api/create-user etc.
//
// Set up admin.yourdomain.com / hotel.yourdomain.com the same way you did
// on Netlify (CNAME → your Pages domain, then add as a Custom Domain in
// Cloudflare Pages → Custom domains) — this middleware only handles the
// routing once the request arrives, not the DNS/certificate side.
// ══════════════════════════════════════════════════════════════════════════
import type { PagesFunction } from "@cloudflare/workers-types";

export const onRequest: PagesFunction = async (context) => {
  const url = new URL(context.request.url);
  const host = url.hostname;

  // Never touch API calls, regardless of which subdomain they arrived on.
  if (url.pathname.startsWith("/api/")) {
    return context.next();
  }

  if (host.startsWith("admin.")) {
    if (url.pathname === "/") {
      url.pathname = "/admin/login";
      return Response.redirect(url.toString(), 301);
    }
    if (!url.pathname.startsWith("/admin")) {
      // Rewrite (not redirect) admin.yourdomain.com/* -> /admin/*, same as
      // the Netlify `to = "/admin/:splat", status = 200` rule.
      const rewritten = new URL(url.toString());
      rewritten.pathname = `/admin${url.pathname}`;
      return context.next(new Request(rewritten.toString(), context.request));
    }
    return context.next();
  }

  if (host.startsWith("hotel.")) {
    url.pathname = "/admin/pin";
    return Response.redirect(url.toString(), 301);
  }

  return context.next();
};
